import java.util.Scanner;

public class insertionbaru {

	static void sort(int arr[])
	{
		int n = arr.length;
		for (int i = 1; i < n; ++i) {
			int key = arr[i];
			int j = i - 1;
			
			while (j >= 0 && arr[j] > key) {
				arr[j + 1] = arr[j];
				j = j - 1;
			}
			arr[j + 1] = key;
		}
	}
	public static void main(String [] args ) {
		Scanner scan = new Scanner(System.in);
		System.out.println("insertionSort\n");
		int n,i;
		System.out.println("berapa banyak ingin di sort");
		n = scan.nextInt();
		int arr[] = new int [n];
		System.out.println("Masukkan nilai"+ n +" element int" );
		for(i=0;i<n;i++)
			arr[i] = scan.nextInt();
		sort(arr);
		System.out.println("\nElement integer setelah diurutkan ");       
	for (i = 0; i < n; i++)
	           System.out.print(arr[i]+" ");           
		       System.out.println();                    
		   }   
	
	
}